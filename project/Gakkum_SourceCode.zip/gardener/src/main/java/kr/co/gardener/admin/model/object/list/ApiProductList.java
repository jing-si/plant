package kr.co.gardener.admin.model.object.list;

import kr.co.gardener.admin.model.object.ApiProduct;
import kr.co.gardener.util.CommonList;

public class ApiProductList extends CommonList<ApiProduct>{

	public ApiProductList() {
		super("Api 제품 리스트");
	}

	
}
