package kr.co.gardener.main.dao;

import kr.co.gardener.admin.model.user.User;

public interface SettingDao {

	void out(User item);

}
