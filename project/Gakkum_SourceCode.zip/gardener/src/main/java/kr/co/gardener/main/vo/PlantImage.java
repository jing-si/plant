package kr.co.gardener.main.vo;

import java.util.List;

public class PlantImage {
	private int plantId;
	private List<String> plantImage;
	
	public int getPlantId() {
		return plantId;
	}
	public void setPlantId(int plantId) {
		this.plantId = plantId;
	}
	public List<String> getPlantImage() {
		return plantImage;
	}
	public void setPlantImage(List<String> plantImage) {
		this.plantImage = plantImage;
	}
		
	
	
	
}
