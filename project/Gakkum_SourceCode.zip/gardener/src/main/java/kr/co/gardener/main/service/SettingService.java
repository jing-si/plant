package kr.co.gardener.main.service;

import kr.co.gardener.admin.model.user.User;

public interface SettingService {

	void out(User item);

}
