package kr.co.gardener.admin.model.forest;

import kr.co.gardener.util.GridSystem;

public class Forest extends GridSystem {
	private int forestId;
	private String forestName;
	private String forestImage; 
	private String forestInfo;
	
	public int getForestId() {
		return forestId;
	}
	public void setForestId(int forestId) {
		this.forestId = forestId;
	}
	public String getForestName() {
		return forestName;
	}
	public void setForestName(String forestName) {
		this.forestName = forestName;
	}
	public String getForestImage() {
		return forestImage;
	}
	public void setForestImage(String forestImage) {
		this.forestImage = forestImage;
	}
	public String getForestInfo() {
		return forestInfo;
	}
	public void setForestInfo(String forestInfo) {
		this.forestInfo = forestInfo;
	}
	
}
