package kr.co.gardener.admin.model.object;

import kr.co.gardener.util.GridSystem;

public class TopClass extends GridSystem{
	private int topClassId;
	private String topClassName;
	
	public int getTopClassId() {
		return topClassId;
	}
	public void setTopClassId(int topClassId) {
		this.topClassId = topClassId;
	}
	public String getTopClassName() {
		return topClassName;
	}
	public void setTopClassName(String topClassName) {
		this.topClassName = topClassName;
	}
	
	
}
