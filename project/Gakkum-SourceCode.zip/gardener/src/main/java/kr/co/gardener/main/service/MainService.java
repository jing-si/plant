package kr.co.gardener.main.service;

public interface MainService {

}
