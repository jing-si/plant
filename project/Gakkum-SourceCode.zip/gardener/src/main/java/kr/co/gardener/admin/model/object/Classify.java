package kr.co.gardener.admin.model.object;

public class Classify{
	private int primaryId;
	private int foreginId;
	private String name;
	private int table;
	
	public int getPrimaryId() {
		return primaryId;
	}
	public void setPrimaryId(int primaryId) {
		this.primaryId = primaryId;
	}
	public int getForeginId() {
		return foreginId;
	}
	public void setForeginId(int foreginId) {
		this.foreginId = foreginId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTable() {
		return table;
	}
	public void setTable(int table) {
		this.table = table;
	}
		
	
}
